# PlayerKits2
https://www.spigotmc.org/resources/playerkits-2-fully-configurable-kits-1-8-1-20.112616/
 
