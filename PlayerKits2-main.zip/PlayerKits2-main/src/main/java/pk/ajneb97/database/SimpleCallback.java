package pk.ajneb97.database;

public interface SimpleCallback {

    void onDone();
}
