package pk.ajneb97.database;

import pk.ajneb97.model.PlayerData;

public interface PlayerCallback {

    void onDone(PlayerData player);
}
