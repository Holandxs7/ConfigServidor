You need to select a pull request template!

If you're adding a new feature, copy and paste the following parameter at the end of the URL:
    ?template=new-feature.md

If you're fixing a bug, copy and paste the following parameter at the end of the URL:
    ?template=bug-fix.md

For more information about contributing to EssentialsX, see CONTRIBUTING.md:
    https://github.com/EssentialsX/Essentials/blob/2.x/CONTRIBUTING.md
