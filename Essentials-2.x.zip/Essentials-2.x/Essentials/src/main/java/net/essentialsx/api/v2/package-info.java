/**
 * API classes, services, and events provided by EssentialsX 2.x.
 */
package net.essentialsx.api.v2;
