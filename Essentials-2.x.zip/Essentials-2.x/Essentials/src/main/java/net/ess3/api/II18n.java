package net.ess3.api;

/**
 * Provides access to the current locale in use.
 */
public interface II18n extends com.earth2me.essentials.api.II18n {

}
