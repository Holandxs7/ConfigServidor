package net.ess3.api;

/**
 * Do not use this class.
 * This class proxies {@link com.earth2me.essentials.api.Economy}.
 * <p>
 * If you want to interact with EssentialsX's economy, we recommend using Vault or {@link com.earth2me.essentials.api.Economy}.
 */
@Deprecated
public class Economy extends com.earth2me.essentials.api.Economy {

}
