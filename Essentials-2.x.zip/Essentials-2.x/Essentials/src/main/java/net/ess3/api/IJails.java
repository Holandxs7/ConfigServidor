package net.ess3.api;

/**
 * This interface may contain future additions to the jails API on top of {@link com.earth2me.essentials.api.IJails}.
 *
 * Note: Maintainers should add methods to {@link com.earth2me.essentials.api.IWarps}.
 */
public interface IJails extends com.earth2me.essentials.api.IJails {

}
