package net.ess3.api;

/**
 * This interface may contain future additions to the warps API on top of {@link com.earth2me.essentials.IUser}.
 *
 * Note: Maintainers should add methods to {@link com.earth2me.essentials.IUser}.
 */
public interface IUser extends com.earth2me.essentials.IUser {

}
