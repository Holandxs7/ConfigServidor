package net.ess3.api;

/**
 * @deprecated This API is not asynchronous. Use {@link com.earth2me.essentials.api.IAsyncTeleport IAsyncTeleport}
 */
public interface ITeleport extends com.earth2me.essentials.api.ITeleport {

}
