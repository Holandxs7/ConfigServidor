package net.ess3.api;

/**
 *
 */
public interface ISettings extends com.earth2me.essentials.ISettings {
}
