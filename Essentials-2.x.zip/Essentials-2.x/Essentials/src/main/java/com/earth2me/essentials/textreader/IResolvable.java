package com.earth2me.essentials.textreader;

public interface IResolvable {
    int getLineCount();
}
