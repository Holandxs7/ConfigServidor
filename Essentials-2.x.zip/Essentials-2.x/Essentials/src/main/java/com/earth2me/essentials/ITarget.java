package com.earth2me.essentials;

import org.bukkit.Location;

public interface ITarget {
    Location getLocation();
}
