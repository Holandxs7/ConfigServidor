package com.earth2me.essentials;

public interface IConf {
    void reloadConfig();
}
