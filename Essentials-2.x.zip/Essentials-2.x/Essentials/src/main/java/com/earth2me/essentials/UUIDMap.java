package com.earth2me.essentials;

@Deprecated
public class UUIDMap {
    public UUIDMap() {
    }

    public void writeUUIDMap() {
        //no-op
    }

    public void forceWriteUUIDMap() {
        //no-op
    }

    public void shutdown() {
        //no-op
    }
}
