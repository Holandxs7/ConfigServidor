package com.earth2me.essentials;

public interface IEssentialsModule {
}
