package com.earth2me.essentials.api;

/**
 * Thrown when a user does not have the balance for a transaction and cannot take a loan.
 */
public class NoLoanPermittedException extends net.ess3.api.NoLoanPermittedException {

}
